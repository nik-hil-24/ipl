import { useEffect, useRef, useState } from 'react';
import { login as cognitoLogin, logout as cognitoLogout, refreshSession } from './cognitoAuth';
import { AuthContext } from './authContextObject';

// Refresh this many ms before the ID token actually expires.
const REFRESH_MARGIN_MS = 5 * 60 * 1000; // 5 min

export function AuthProvider({ children }) {
  const [tokens, setTokens] = useState(null); // { idToken, accessToken, refreshToken, expiresAt }
  const [status, setStatus] = useState('loading'); // 'loading' | 'authed' | 'anon'
  const refreshTimer = useRef(null);

  function scheduleRefresh(expiresAt) {
    if (refreshTimer.current) clearTimeout(refreshTimer.current);
    const delay = Math.max(expiresAt - Date.now() - REFRESH_MARGIN_MS, 0);
    refreshTimer.current = setTimeout(async () => {
      const fresh = await refreshSession();
      if (fresh) {
        setTokens(fresh);
        scheduleRefresh(fresh.expiresAt);
      } else {
        // Refresh token expired too — force back to login.
        setTokens(null);
        setStatus('anon');
      }
    }, delay);
  }

  // On mount: Cognito's own SDK caches the last session in localStorage under the hood,
  // so getCurrentUser()/getSession() in refreshSession() will silently restore it if valid.
  useEffect(() => {
    (async () => {
      const restored = await refreshSession();
      if (restored) {
        setTokens(restored);
        setStatus('authed');
        scheduleRefresh(restored.expiresAt);
      } else {
        setStatus('anon');
      }
    })();
    return () => {
      if (refreshTimer.current) clearTimeout(refreshTimer.current);
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  async function handleLogin(email, password) {
    const fresh = await cognitoLogin(email, password);
    setTokens(fresh);
    setStatus('authed');
    scheduleRefresh(fresh.expiresAt);
    return fresh;
  }

  function handleLogout() {
    if (refreshTimer.current) clearTimeout(refreshTimer.current);
    cognitoLogout();
    setTokens(null);
    setStatus('anon');
  }

  const value = {
    status, // consumers should treat 'loading' as "don't redirect yet"
    isAuthed: status === 'authed',
    idToken: tokens?.idToken ?? null,
    login: handleLogin,
    logout: handleLogout,
  };

  return <AuthContext.Provider value={value}>{children}</AuthContext.Provider>;
}
