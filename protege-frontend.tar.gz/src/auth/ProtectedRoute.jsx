import { Navigate, useLocation } from 'react-router-dom';
import { useAuth } from './useAuth';

export function ProtectedRoute({ children }) {
  const { status, isAuthed } = useAuth();
  const location = useLocation();

  if (status === 'loading') {
    // Still checking for a cached Cognito session — avoid flashing the login page.
    return <div className="full-page-loading">Loading…</div>;
  }

  if (!isAuthed) {
    return <Navigate to="/login" state={{ from: location }} replace />;
  }

  return children;
}
