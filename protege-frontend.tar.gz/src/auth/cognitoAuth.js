import {
  CognitoUserPool,
  CognitoUser,
  AuthenticationDetails,
} from 'amazon-cognito-identity-js';
import { cognitoConfig } from './cognitoConfig';

const userPool = new CognitoUserPool({
  UserPoolId: cognitoConfig.userPoolId,
  ClientId: cognitoConfig.clientId,
});

/**
 * Logs in with USER_PASSWORD_AUTH.
 * Resolves with { idToken, accessToken, refreshToken, expiresAt }.
 * Rejects with the raw Cognito error (has .code, e.g. NotAuthorizedException).
 */
export function login(email, password) {
  return new Promise((resolve, reject) => {
    const user = new CognitoUser({ Username: email, Pool: userPool });
    const authDetails = new AuthenticationDetails({
      Username: email,
      Password: password,
    });

    user.authenticateUser(authDetails, {
      onSuccess: (session) => {
        resolve(sessionToTokens(session));
      },
      onFailure: (err) => {
        reject(err);
      },
      // NEW_PASSWORD_REQUIRED etc. intentionally not handled yet — out of scope per spec ("optional later")
    });
  });
}

export function logout() {
  const user = userPool.getCurrentUser();
  if (user) {
    user.signOut();
  }
}

/**
 * Attempts silent refresh using the current Cognito user's cached session.
 * Resolves with fresh tokens, or null if there's no logged-in user / refresh fails.
 */
export function refreshSession() {
  return new Promise((resolve) => {
    const user = userPool.getCurrentUser();
    if (!user) {
      resolve(null);
      return;
    }
    user.getSession((err, session) => {
      if (err || !session || !session.isValid()) {
        resolve(null);
        return;
      }
      resolve(sessionToTokens(session));
    });
  });
}

function sessionToTokens(session) {
  const idToken = session.getIdToken();
  return {
    idToken: idToken.getJwtToken(),
    accessToken: session.getAccessToken().getJwtToken(),
    refreshToken: session.getRefreshToken().getToken(),
    expiresAt: idToken.getExpiration() * 1000, // ms epoch
  };
}
