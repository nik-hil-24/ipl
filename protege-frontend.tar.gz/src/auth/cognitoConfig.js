// Cognito config for Protégé.
// Hardcoded for PoC — flip to env vars only if/when this needs per-env builds.

export const cognitoConfig = {
  region: 'ap-northeast-1',
  userPoolId: 'ap-northeast-1_en1BUZ2sf',
  clientId: '3ck1jgtvf7mg6anjds9kp1p8c0',
};

export const wsApiUrl = 'wss://1cq0mgn5h0.execute-api.ap-northeast-1.amazonaws.com/prod';

// HTTP API for conversation history — not built yet on the backend.
// Pointing this at the same API Gateway base for now; update when that endpoint exists.
export const httpApiUrl = 'https://TBD.execute-api.ap-northeast-1.amazonaws.com/prod';
