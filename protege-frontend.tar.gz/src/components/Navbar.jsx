import { NavLink } from 'react-router-dom';
import { useAuth } from '../auth/useAuth';
import '../styles/navbar.css';

export function Navbar() {
  const { logout } = useAuth();

  return (
    <nav className="navbar">
      <div className="navbar-brand">Protégé</div>
      <div className="navbar-links">
        <NavLink to="/dashboard" className="navbar-link">
          Dashboard
        </NavLink>
        <NavLink to="/chat" className="navbar-link">
          AI Chat
        </NavLink>
      </div>
      <div className="navbar-user">
        <button className="navbar-logout" onClick={logout}>
          Log out
        </button>
      </div>
    </nav>
  );
}
