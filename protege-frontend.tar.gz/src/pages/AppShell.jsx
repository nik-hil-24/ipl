import { Outlet } from 'react-router-dom';
import { Navbar } from '../components/Navbar';

export function AppShell() {
  return (
    <div className="app-shell">
      <Navbar />
      <div className="app-shell-content">
        <Outlet />
      </div>
    </div>
  );
}
