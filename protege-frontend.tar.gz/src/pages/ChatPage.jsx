export function ChatPage() {
  return (
    <div className="page-placeholder">
      <h2>AI Chat</h2>
      <p>WebSocket chat interface — coming in Step 4.</p>
    </div>
  );
}
