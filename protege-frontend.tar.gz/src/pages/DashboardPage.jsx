export function DashboardPage() {
  return (
    <div className="page-placeholder">
      <h2>Dashboard</h2>
      <p>Portfolio overview metrics go here. (Content TBD.)</p>
    </div>
  );
}
